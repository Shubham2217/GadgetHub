/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package in.gadgethub.utility;

/**
 *
 * @author Hp
 */
public class AppInfo {
   public static final String appName = "GadgetHub" ;
   public static final String appEmail = "xyz" ;
   public static final String appPassword = "xyz" ;
    
}
